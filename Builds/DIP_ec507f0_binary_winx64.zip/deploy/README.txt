DPI -- Diptrace Pin Importer

This is a small program to read a CSV file with a list of pins and group the pins are in, then export a Diptrace ASCII file with all the pin broken into component parts.
The output file can be inported into Diptrace component editor and manipulated from there.

Input CVS file format:
Input columns: Pin Name,Pin,Sub Part

Pin Name: Free from string for the name of the device pin
Pin: The Pin Number/Designator (ie: 1,2 A3, AA42)
Sub Part: A number designating this pin should be grouped with other pins of the same number.
          A component in Diptrace can have multiple sub parts, this indicates which sub part the pin is grouped with.

          
Running:
This program is compiled for Windows x64 environment.  You may need a vc runtime for vc2017.
This program runs in place.   Just extract it to a destination folder and run the DPI.exe program.
The QT5 DLLs provided must be in the same dir as the EXE for the program to run correctly.
